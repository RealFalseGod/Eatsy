package com.i.eateasy2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

import java.util.HashMap;
import java.util.Map;

public class PostAdapter extends FirebaseRecyclerAdapter<Post, PostAdapter.PastViewHolder> {
    private Context context;
    public PostAdapter(@NonNull FirebaseRecyclerOptions<Post> options,Context context) {
        super(options);
        this.context= context;
    }

    @Override
    protected void onBindViewHolder(@NonNull PastViewHolder holder, @SuppressLint("RecyclerView") int position, @NonNull Post post) {
        holder.list.setText(post.getList());
        holder.cost.setText(post.getCost());
        holder.tableno.setText(post.getTableno());
        holder.description.setText(post.getDescription());
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String to="T"+post.getTableno();
                FirebaseDatabase.getInstance().getReference().child("Table").child(to).setValue("0");
                FirebaseDatabase.getInstance().getReference().child("Post")
                        .child(getRef(position).getKey()).removeValue()
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                            }
                        });
            }
        });

    }

    @NonNull
    @Override
    public PastViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.post, parent, false);

        return new PastViewHolder(view);
    }

    class PastViewHolder extends RecyclerView.ViewHolder{
        TextView list,description,tableno,cost;
        ImageView delete;
        public PastViewHolder(@NonNull View itemView) {
            super(itemView);
            tableno = itemView.findViewById(R.id.tableno);
            cost = itemView.findViewById(R.id.cost);
            list = itemView.findViewById(R.id.list);
            description = itemView.findViewById(R.id.description);
            delete = itemView.findViewById(R.id.delete);

        }
    }
}
