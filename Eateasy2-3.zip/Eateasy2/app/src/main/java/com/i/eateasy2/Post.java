package com.i.eateasy2;

public class Post {
    String list;
    String description;
    String tableno;
    String cost;

    @Override
    public String toString() {
        return "Post{" +
                "tableno='" + tableno + '\'' +
                "list='" + list + '\'' +
                ", description='" + description + '\'' +
                "cost='" + cost + '\'' +
                '}';
    }

    public Post() {
    }
    public String getTableno() {
        return tableno;
    }

    public void setTableno(String tableno) {
        this.tableno = tableno;
    }

    public String getList() {
        return list;
    }

    public void setList(String list) {
        this.list = list;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }
}
