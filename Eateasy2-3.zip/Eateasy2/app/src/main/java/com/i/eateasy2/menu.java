package com.i.eateasy2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class menu extends AppCompatActivity {
    String f1="",list,f2="",f3="",f4="",f5="",f6="",f7="",f8="",f9="",f10="",f11="";
    String tol;
    private TextView tableno;
    private EditText description;
    DataSnapshot snapshot;
    private DatabaseReference Post,his,tab;
    Button add1,minus1,add2,minus2,ordernow,home,add3,minus3,add4,minus4,add5,minus5,add6,minus6,add7,minus7,add8,minus8,add9,minus9,add10,minus10,add11,minus11;
    TextView no1,no2,cost,no3,no4,no5,no6,no7,no8,no9,no10,no11;
    String val;
    int n1=0,n2=0,total=0,n3=0,n4=0,n5=0,n6=0,n7=0,n8=0,n9=0,n10=0,n11=0;
    int c1=20,c2=10,c3=10,c4=50,c5=60,c6=40,c7=20,c8=80,c9=60,c10=35,c11=4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        add1 = findViewById(R.id.add1);
        minus1 = findViewById(R.id.minus1);
        no1 = findViewById(R.id.no1);
        add3 = findViewById(R.id.add3);
        minus3 = findViewById(R.id.minus3);
        no3 = findViewById(R.id.no3);
        add4 = findViewById(R.id.add4);
        minus4 = findViewById(R.id.minus4);
        no4 = findViewById(R.id.no4);
        add5 = findViewById(R.id.add5);
        minus5 = findViewById(R.id.minus5);
        no5 = findViewById(R.id.no5);
        add6 = findViewById(R.id.add6);
        minus6 = findViewById(R.id.minus6);
        no6 = findViewById(R.id.no6);
        add7 = findViewById(R.id.add7);
        minus7 = findViewById(R.id.minus7);
        no7 = findViewById(R.id.no7);
        add8 = findViewById(R.id.add8);
        minus8 = findViewById(R.id.minus8);
        no8 = findViewById(R.id.no8);
        add9 = findViewById(R.id.add9);
        minus9 = findViewById(R.id.minus9);
        no9 = findViewById(R.id.no9);
        add10 = findViewById(R.id.add10);
        minus10 = findViewById(R.id.minus10);
        no10 = findViewById(R.id.no10);
        add11 = findViewById(R.id.add11);
        minus11 = findViewById(R.id.minus11);
        no11 = findViewById(R.id.no11);
        add2 = findViewById(R.id.add2);
        minus2 = findViewById(R.id.minus2);
        home = findViewById(R.id.home);
        tableno = findViewById(R.id.tableno);
        description = findViewById(R.id.description);
        no2 = findViewById(R.id.no2);
        cost = findViewById(R.id.cost);
        ordernow= findViewById(R.id.ordernow);
        Post = FirebaseDatabase.getInstance().getReference().child("Post");
        his = FirebaseDatabase.getInstance().getReference().child("Past");
        tab = FirebaseDatabase.getInstance().getReference();
        tab.child("Table").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String t1 =snapshot.child("T1").getValue(String.class);
                String t2 =snapshot.child("T2").getValue(String.class);
                String t3 =snapshot.child("T3").getValue(String.class);
                String t4 =snapshot.child("T4").getValue(String.class);
                String t5 =snapshot.child("T5").getValue(String.class);
                String t6 =snapshot.child("T6").getValue(String.class);
                String t7 =snapshot.child("T7").getValue(String.class);
                String t8 =snapshot.child("T8").getValue(String.class);
                String t9 =snapshot.child("T9").getValue(String.class);
                String t10 =snapshot.child("T10").getValue(String.class);
                if(t1.equals("0"))
                {
                    tol="1";

                }
                else if(t2.equals("0"))
                {
                    tol="2";

                }
                else if(t3.equals("0"))
                {
                    tol="3";

                }
                else if(t4.equals("0"))
                {
                    tol="4";

                }
                else if(t5.equals("0"))
                {
                    tol="5";

                }
                else if(t6.equals("0"))
                {
                    tol="6";

                }
                else if(t7.equals("0"))
                {
                    tol="7";

                }
                else if(t8.equals("0"))
                {
                    tol="8";

                }
                else if(t9.equals("0"))
                {
                    tol="9";

                }
                else if(t10.equals("0"))
                {
                    tol="10";

                }
                else
                {
                    Intent intent = new Intent(getApplicationContext(),notables.class);
                    startActivity(intent);
                    finish();
                }
                String cat="Table no : "+tol;
                tableno.setText(cat);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        add1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+1;
                total = total +c1;
                no1.setText(Integer.toString(n1));
                cost.setText(Integer.toString(total));
                if (n1!=0)
                {
                    f1 ="Sandwich : "+Integer.toString(n1)+" ";
                }
                list = list+f1;
            }
        });
        minus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n1!=0)
                {
                    n1=n1-1;
                    total = total -c1;
                    no1.setText(Integer.toString(n1));
                    cost.setText(Integer.toString(total));
                    f1 ="Sandwich : "+Integer.toString(n1)+" ";
                }
                if (n1==0)
                {
                    f1="";
                }
                list = list+f1;

            }
        });
        add2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n2=n2+1;
                total = total +c2;
                no2.setText(Integer.toString(n2));
                cost.setText(Integer.toString(total));
                if (n2!=0)
                {
                    f2 ="Samosa : "+Integer.toString(n2)+" ";
                }
            }
        });
        minus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n2!=0)
                {
                    n2=n2-1;
                    total = total -c2;
                    no2.setText(Integer.toString(n2));
                    cost.setText(Integer.toString(total));
                    f2 ="Samosa : "+Integer.toString(n2)+" ";
                }
                if (n2==0)
                {
                    f2="";
                }
            }
        });
        add3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n3=n3+1;
                total = total +c3;
                no3.setText(Integer.toString(n3));
                cost.setText(Integer.toString(total));
                if (n3!=0)
                {
                    f3 ="Vadapav : "+Integer.toString(n3)+" ";
                }
                list = list+f3;
            }
        });
        minus3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n3!=0)
                {
                    n3=n3-1;
                    total = total -c3;
                    no3.setText(Integer.toString(n3));
                    cost.setText(Integer.toString(total));
                    f3 ="Vadapav : "+Integer.toString(n3)+" ";
                }
                if (n3==0)
                {
                    f3="";
                }
                list = list+f3;

            }
        });
        add4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n4=n4+1;
                total = total +c4;
                no4.setText(Integer.toString(n4));
                cost.setText(Integer.toString(total));
                if (n4!=0)
                {
                    f4 ="Noodles : "+Integer.toString(n4)+" ";
                }
                list = list+f4;
            }
        });
        minus4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n4!=0)
                {
                    n4=n4-1;
                    total = total -c4;
                    no4.setText(Integer.toString(n4));
                    cost.setText(Integer.toString(total));
                    f4 ="Noodles : "+Integer.toString(n4)+" ";
                }
                if (n4==0)
                {
                    f4="";
                }
                list = list+f4;

            }
        });
        add5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n5=n5+1;
                total = total +c5;
                no5.setText(Integer.toString(n5));
                cost.setText(Integer.toString(total));
                if (n5!=0)
                {
                    f5 ="Manchurian : "+Integer.toString(n5)+" ";
                }
                list = list+f5;
            }
        });
        minus5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n5!=0)
                {
                    n5=n5-1;
                    total = total -c5;
                    no5.setText(Integer.toString(n5));
                    cost.setText(Integer.toString(total));
                    f5 ="Manchurian : "+Integer.toString(n5)+" ";
                }
                if (n5==0)
                {
                    f5="";
                }
                list = list+f5;

            }
        });
        add6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n6=n6+1;
                total = total +c6;
                no6.setText(Integer.toString(n6));
                cost.setText(Integer.toString(total));
                if (n6!=0)
                {
                    f6 ="Paneer Roll : "+Integer.toString(n6)+" ";
                }
                list = list+f6;
            }
        });
        minus6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n6!=0)
                {
                    n6=n6-1;
                    total = total -c6;
                    no6.setText(Integer.toString(n6));
                    cost.setText(Integer.toString(total));
                    f6 ="Paneer Roll : "+Integer.toString(n6)+" ";
                }
                if (n6==0)
                {
                    f6="";
                }
                list = list+f6;

            }
        });
        add7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n7=n7+1;
                total = total +c7;
                no7.setText(Integer.toString(n7));
                cost.setText(Integer.toString(total));
                if (n7!=0)
                {
                    f7 ="Egg Roll : "+Integer.toString(n7)+" ";
                }
                list = list+f7;
            }
        });
        minus7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n7!=0)
                {
                    n7=n7-1;
                    total = total -c7;
                    no7.setText(Integer.toString(n7));
                    cost.setText(Integer.toString(total));
                    f7 ="Egg Roll : "+Integer.toString(n7)+" ";
                }
                if (n7==0)
                {
                    f7="";
                }
                list = list+f7;

            }
        });
        add8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n8=n8+1;
                total = total +c8;
                no8.setText(Integer.toString(n8));
                cost.setText(Integer.toString(total));
                if (n8!=0)
                {
                    f8 ="Pav Bhaji : "+Integer.toString(n8)+" ";
                }
                list = list+f8;
            }
        });
        minus8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n8!=0)
                {
                    n8=n8-1;
                    total = total -c8;
                    no8.setText(Integer.toString(n8));
                    cost.setText(Integer.toString(total));
                    f8 ="Pav Bhaji : "+Integer.toString(n8)+" ";
                }
                if (n8==0)
                {
                    f8="";
                }
                list = list+f8;

            }
        });
        add9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n9=n9+1;
                total = total +c9;
                no9.setText(Integer.toString(n9));
                cost.setText(Integer.toString(total));
                if (n9!=0)
                {
                    f9 ="Pav Bhaji : "+Integer.toString(n9)+" ";
                }
                list = list+f9;
            }
        });
        minus9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n9!=0)
                {
                    n9=n9-1;
                    total = total -c9;
                    no9.setText(Integer.toString(n9));
                    cost.setText(Integer.toString(total));
                    f9 ="Pav Bhaji : "+Integer.toString(n9)+" ";
                }
                if (n9==0)
                {
                    f9="";
                }
                list = list+f9;

            }
        });
        add10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n10=n10+1;
                total = total +c10;
                no10.setText(Integer.toString(n10));
                cost.setText(Integer.toString(total));
                if (n10!=0)
                {
                    f10 ="Aloo Paratha : "+Integer.toString(n10)+" ";
                }
                list = list+f10;
            }
        });
        minus10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n10!=0)
                {
                    n10=n10-1;
                    total = total -c10;
                    no10.setText(Integer.toString(n10));
                    cost.setText(Integer.toString(total));
                    f10 ="Aloo Paratha : "+Integer.toString(n10)+" ";
                }
                if (n10==0)
                {
                    f10="";
                }
                list = list+f10;

            }
        });
        add11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n11=n11+1;
                total = total +c11;
                no11.setText(Integer.toString(n11));
                cost.setText(Integer.toString(total));
                if (n11!=0)
                {
                    f11 ="Pavv : "+Integer.toString(n11)+" ";
                }
                list = list+f11;
            }
        });
        minus11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n11!=0)
                {
                    n11=n11-1;
                    total = total -c11;
                    no11.setText(Integer.toString(n11));
                    cost.setText(Integer.toString(total));
                    f11 ="Pavv : "+Integer.toString(n11)+" ";
                }
                if (n11==0)
                {
                    f11="";
                }
                list = list+f11;

            }
        });

        ordernow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val =tol;
                String to = "T"+val;
                tab.child("Table").child(to).setValue("1");
                if (TextUtils.isEmpty(val)){
                    Toast.makeText(menu.this, "Enter table no", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (total==0){
                    Toast.makeText(menu.this, "Please Select a Food item", Toast.LENGTH_SHORT).show();
                    return;
                }
                list = f1+f2+f3+f4+f5+f6+f7+f8+f9+f10+f11;
                save();
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
    private void save() {
        HashMap<String,Object> map = new HashMap<>();
        map.put("list",list);
        map.put("tableno",tol);
        map.put("description",description.getText().toString());
        map.put("cost",Integer.toString(total));
        his.push()
                .setValue(map);
        Post.push()
                .setValue(map)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Log.i("jack","onComplete:");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.i("jack3","onFailure:"+e.toString());
                    }
                });
        Intent intent = new Intent(getApplicationContext(),thankyou.class);
        startActivity(intent);
        finish();
    }
}